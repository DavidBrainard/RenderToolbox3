27 July 2012
Notes on Macbeth Color Checker spectrum data.

David Brainard created sur_mccBabel.mat based on data from Danny Pascale at BabelColor.com:

http://www.babelcolor.com/main_level/ColorChecker.htm

Note that data at that site have been updated since the creation of sur_mccBabel.mat.

Individual .spd files were generated from sur_mccBabel.mat, using the ColorimetricToSPDFiles.m converter which is part of RenderToolbox3.